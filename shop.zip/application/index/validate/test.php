<?php

namespace app\index\validate;

use think\Validate;

class test extends Validate
{

	
	//自定义规则
    protected $rule =   [
         
    ];
    
    //定义信息
    protected $message  =   [
          
    ];
}
