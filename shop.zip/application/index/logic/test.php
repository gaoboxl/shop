<?php

namespace app\index\logic;

use think\Controller;

class test 
{
    //
}
