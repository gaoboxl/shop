<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"D:\www\shop\public/../application/admin\view\admin\auth.html";i:1513656588;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> 添加数据 </title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">
   

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        
       
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>菜单列表 <small>添加数据</small></h5>
                        
                    </div>
                    <div class="ibox-content">
                        <form method="post" class="form-horizontal" action="<?php echo url('admin/auth'); ?>">
                            
                            <input type="hidden" name="id" value="<?php echo $admin['admin_id']; ?>">

                            <div class="form-group">
                                  <table class="table table-striped table-bordered table-hover " id="editable">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" onclick="choosebox(this)" >全选 </th>
                                                <th>权限规则</th>
                                            </tr>
                                            
                                        </thead>
                                        <tbody>
                                        <?php if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): $i = 0; $__LIST__ = $menus;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu): $mod = ($i % 2 );++$i;if(($menu['pid'] == 0)): ?>
                                            <tr class="gradeX">
                                                
                                                <td> <label> <input type="checkbox" value="<?php echo $menu['id']; ?>" name="rule_id[]"  <?php if(isset($admin['rule_id']) &&  in_array($menu['id'],$admin['rule_id'])): ?> checked <?php endif; ?>  cka="mod-<?php echo $menu['id']; ?>"> <i></i> </label> <?php echo $menu['name']; ?></td>
                                                <td> 
                                                    <?php if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): $i = 0; $__LIST__ = $menus;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;if(($child['pid'] == $menu['id'])): ?>
                                                            <label> <input type="checkbox" name="rule_id[]" ck="mod-<?php echo $menu['id']; ?>" <?php if(isset($admin['rule_id']) &&  in_array($child['id'],$admin['rule_id'])): ?> checked <?php endif; ?>   value="<?php echo $child['id']; ?>"> <i></i> <?php echo $child['name']; ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                                </td>

                                            </tr> 
                                            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                        </tbody>
                                    </table>
                            </div>
                            <div class="hr-line-dashed"></div>

                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">确定</button>
                                    <button class="btn btn-white" type="button" onClick="javascript :history.back(-1);" >取消</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/content.js?v=1.0.0"></script>

    <script>

        //全选
        function choosebox(o){
            var vt = $(o).is(':checked');
            if(vt){
                $('input[type=checkbox]').prop('checked',vt);
            }else{
                $('input[type=checkbox]').removeAttr('checked');
            }
        }

        //组选
        $(":checkbox[cka]").click(function(){
                var $cks = $(":checkbox[ck='"+$(this).attr("cka")+"']");
                if($(this).is(':checked')){
                    $cks.each(function(){$(this).prop("checked",true);});
                }else{
                    $cks.each(function(){$(this).removeAttr('checked');});
                }
            });

    </script>

    
    

</body>

</html>
