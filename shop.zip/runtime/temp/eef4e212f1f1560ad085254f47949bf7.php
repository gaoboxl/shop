<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:62:"D:\www\yuyue\public/../application/admin\view\order\index.html";i:1513318663;}*/ ?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title> 数据列表 </title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">

    <!-- 表格样式 -->
    <link href="__admin_style__/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
       
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>数据列表</h5>
                        <div class="ibox-tools"> 
                        </div>
                    </div>
                    <div class="ibox-content">
                       <!--  <div class="col-sm-1">
                            <a  href="create.html" class="btn btn-success ">添加</a>
                        </div>

                        <div class="col-sm-1">
                            <a   class="btn btn-primary " data-toggle="modal" data-target="#myModal">弹框</a>
                        </div> -->

                        <div class="col-sm-4">

                            <div class="input-group">
                                <input type="text" placeholder="请输入你要搜索的内容" class="input form-control">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn btn-primary"> 
                                        <i class="fa fa-search"></i> 搜索
                                    </button>
                                </span>
                            </div>

                        </div>


                        <table class="table table-striped table-bordered table-hover " id="editable">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>名称</th>
                                    <th>时间</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr class="gradeX">
                                    <td>1</td>
                                    <td>小李子</td>
                                    <td>2017-11-26 </td>
                                    <td>
                                        微支付
                                    </td>
                                    <td class="center">
                                        2017-12-12
                                    </td>
                                </tr>

                                <tr class="gradeX">
                                    <td>1</td>
                                    <td>小李子</td>
                                    <td>2017-11-26 </td>
                                    <td>
                                       支付
                                    </td>
                                    <td class="center">
                                       2017-12-12
                                    </td>
                                </tr>

                                <tr class="gradeX">
                                    <td>1</td>
                                    <td>小李子</td>
                                    <td>2017-11-26 </td>
                                    <td>
                                       支付
                                    </td>
                                    <td class="center">
                                       2017-12-12
                                    </td>
                                </tr>
                               
                                
                            </tbody>

                            <div class="col-sm-1">
                                <a   class="btn btn-primary " href="<?php echo url('admin/order/excel'); ?>">导出数据</a>
                            </div> 
    
                           
                        </table>

                        <div class="row">
                            <div class="col-sm-6">
                               <!--  <div class="dataTables_info" id="DataTables_Table_0_info" role="alert" aria-live="polite" aria-relevant="all">显示 1 到 10 项，共 57 项</div> -->
                               
                            </div>
                            <div class="col-sm-6">
                                <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                    <ul class="pagination">
                                        <li class="paginate_button previous disabled" aria-controls="DataTables_Table_0" tabindex="0" id="DataTables_Table_0_previous">
                                            <a href="#">上一页</a>
                                        </li>
                                        <li class="paginate_button active" aria-controls="DataTables_Table_0" tabindex="0">
                                            <a href="#">1</a>
                                        </li>
                                        <li class="paginate_button" aria-controls="DataTables_Table_0" tabindex="0">
                                            <a href="#">2</a>
                                        </li>
                                        <li class="paginate_button" aria-controls="DataTables_Table_0" tabindex="0">
                                            <a href="#">3</a>
                                        </li>
                                        <li class="paginate_button next" aria-controls="DataTables_Table_0" tabindex="0" id="DataTables_Table_0_next">
                                            <a href="#">下一页</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 弹框 -->
  


    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="__admin_style__/js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/plugins/layer/layer.min.js" ></script>

    <script type="text/javascript">
        
        //删除
        function  del(id)
        {

            layer.confirm('您确定要删除？', {
              btn: ['确定','取消'] //按钮
            }, function(){
             // layer.msg('的确很重要', {icon: 1});

                $.get(url,{id:id},function(rs){

                    if(rs.status == 200){
                        setTimeout(function(){
                            window.location.reload();
                        },1500);
                    }

                    layer.msg('的确很重要', {icon: 1});

                });

            });

        }


        //状态
        function  order()
        {   
            var url  =  "<?php echo url('admin/order/excel'); ?>"
            $.get(url,function(rs){

            });
        }


    </script>

</body>

</html>
