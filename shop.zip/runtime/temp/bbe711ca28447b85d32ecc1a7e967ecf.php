<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:62:"D:\www\shop\public/../application/admin\view\goods\create.html";i:1513736395;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> 添加数据 </title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">

    <!-- 文件上传 -->
    <link rel="stylesheet" type="text/css" href="__admin_style__/js/webuploader-0.1.5/webuploader.css" />
    <!-- 验证 -->
    <link rel="stylesheet" href="__admin_style__/dist/css/bootstrapValidator.css"/>

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        
       
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>列表数据 <small>添加数据</small></h5>
                        
                    </div>
                    <form method="post"  action="<?php echo url('goods/save'); ?>" class="form-horizontal" id="myform">

                         <div class="tabs-container">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#tab-1" aria-expanded="true"> 基本数据</a>
                                    </li>
                                    <li class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">商品详情</a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div id="tab-1" class="tab-pane active">
                                        <div class="ibox-content">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">商品名称:</label>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" placeholder="请输入商品名称" name="goods_name"> 
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                             <div class="form-group">
                                                <label class="col-sm-2 control-label">商品原价:</label>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" placeholder="请输入商品原价" name="original_price"> 
                                                </div>
                                            </div>

                                            <div class="hr-line-dashed"></div>
                                             <div class="form-group">
                                                <label class="col-sm-2 control-label">商品折扣价:</label>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" placeholder="请输入折扣价" name="price"> 
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">选择分类:</label>

                                                <div class="col-sm-4">
                                                    <select class="form-control m-b" name="cat_id">
                                                        <option value="">---请选择分类---</option>
                                                        <?php if(is_array($category) || $category instanceof \think\Collection || $category instanceof \think\Paginator): $i = 0; $__LIST__ = $category;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cate): $mod = ($i % 2 );++$i;?>
                                                            <option value="<?php echo $cate['cat_id']; ?>" ><?php echo $cate['name']; ?></option>
                                                        <?php endforeach; endif; else: echo "" ;endif; ?>
                                                       
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">描述:</label>

                                                <div class="col-sm-4">
                                                    <textarea class="form-control" name="desc" rows="5"></textarea>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">封面:</label>
                                                
                                                <div class="col-sm-4">
                                                    <input type="hidden" name="img" value="" id="img">
                                                        <div id="uploader-demo">
                                                            <!--用来存放item-->
                                                            <img  src="" id="cover">
                                                            <div id="fileList" class="uploader-list"></div>
                                                            <div id="filePicker">选择图片<i class="fa fa-upload"></i></div>
                                                        </div>
                                                    
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">状态:</label>

                                                <div class="col-sm-4">
                                                    <div class="switch">
                                                        <div class="onoffswitch">
                                                            <input type="checkbox" checked="" name="status" class="onoffswitch-checkbox" id="example1">
                                                            <label class="onoffswitch-label" for="example1">
                                                                <span class="onoffswitch-inner"></span>
                                                                <span class="onoffswitch-switch"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-primary" type="submit">确定</button>
                                                    <button class="btn btn-white" type="button" onClick="javascript :history.back(-1);" >取消</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="tab-2" class="tab-pane">
                                        <div class="ibox-content">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">富文本：</label>
                                                <div class="col-sm-4">
                                                   <div>
                                                        <script id="editor" type="text/plain" style="width:900px;height:500px;" name="content"></script>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="hr-line-dashed"></div>

                                            <div class="form-group">
                                                <div class="col-sm-4 col-sm-offset-2">
                                                    <button class="btn btn-primary" type="submit">确定</button>
                                                    <button class="btn btn-white" type="button" onClick="javascript :history.back(-1);" >取消</button>
                                                </div>
                                            </div>   
                                        </div>
                                    </div>
                                </div>
                        </div>


               
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/content.js?v=1.0.0"></script>
    <!-- 文件上传 -->
    <script type="text/javascript" src="__admin_style__/js/webuploader-0.1.5/webuploader.js"></script>
    <!-- iCheck -->
    <script src="__admin_style__/js/plugins/iCheck/icheck.min.js"></script>
    <!-- 验证 -->
    <script type="text/javascript" src="__admin_style__/dist/js/bootstrapValidator.js"></script>
    <!-- 编辑器 -->
    <script type="text/javascript" charset="utf-8" src="__admin_style__/js/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="__admin_style__/js/ueditor/ueditor.all.min.js"> </script>
    <script type="text/javascript" charset="utf-8" src="__admin_style__/js/ueditor/lang/zh-cn/zh-cn.js"></script>

    <script>
        $(document).ready(function () {

            $('#myform').bootstrapValidator({
                message: 'This value is not valid',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    goods_name: {
                        message: 'The username is not valid',
                        validators: {
                            notEmpty: {
                                message: '商品名不能为空'
                            },
                            stringLength: {
                                max: 30,
                                message: '商品名称最大为30个字符'
                            }
                           
                        }
                    },
                    price: {
                        validators: {
                            notEmpty: {
                                message: '折扣价不能为空'
                            }
                        }
                    },
                    original_price: {
                        validators: {
                            notEmpty: {
                                message: '原价不能为空'
                            }
                        }
                    },
                    cat_id: {
                        validators: {
                            notEmpty: {
                                message: '请选择商品分类'
                            },
                            
                        }
                    },
                    
                    
                }
            });


            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });

            //编辑器
             var ue = UE.getEditor('editor');

            //文件上传
            // 初始化Web Uploader
            var uploader = WebUploader.create({

                // 选完文件后，是否自动上传。
                auto: true,

                // swf文件路径
                swf:'js/Uploader.swf',

                // 文件接收服务端。
                server: "<?php echo url('Image/upload'); ?>",

                // 选择文件的按钮。可选。
                // 内部根据当前运行是创建，可能是input元素，也可能是flash.
                pick: '#filePicker',

                // 只允许选择图片文件。
                accept: {
                    title: 'Images',
                    extensions: 'gif,jpg,jpeg,bmp,png',
                    mimeTypes: 'image/*'
                }
            });


            // 文件上传成功回调
            uploader.on( 'uploadSuccess', function( file , response ) {
                $('#cover').attr('src',response.data.path);
                $('#img').val(response.data.id);
            });


        });
    </script>

    
    

</body>

</html>
