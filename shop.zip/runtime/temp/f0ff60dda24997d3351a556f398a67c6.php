<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\www\shop\public/../application/admin\view\index\index.html";i:1513647287;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">
    <title> 小李子后台系统</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <!--[if lt IE 9]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">
</head>

<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
    <div id="wrapper">
        <!--左侧导航开始-->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="nav-close"><i class="fa fa-times-circle"></i>
            </div>
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
    
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <span><img alt="image" class="img-circle" src="__admin_style__/img/logo.png"></span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                    <span class="clear">
                                   <span class="block m-t-xs"><strong class="font-bold">美丽攻略.半永久</strong></span>
                                    <span class="text-muted text-xs block"><?php echo (isset($admin_info['name']) && ($admin_info['name'] !== '')?$admin_info['name']:''); ?><b class="caret"></b></span>
                                    </span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li>
                                    <a class="J_menuItem" href="form_avatar.html" data-index="0">修改头像</a>
                                </li>
                                <li>
                                    <a class="J_menuItem" href="profile.html" data-index="1">个人资料</a>
                                </li>
                                <li>
                                    <a class="J_menuItem" href="contacts.html" data-index="2">修改密码</a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="<?php echo url('login/logout'); ?>">安全退出</a>
                                </li>
                            </ul>

                        </div>
                           <div class="logo-element">美丽攻略
                        </div>
                    </li>
                    <li>
                        <a class="J_menuItem" href="<?php echo url('admin/index/welcome'); ?>">
                            <i class="fa fa-home"></i>
                            <span class="nav-label">主页</span>
                        </a>
                    </li>
                    <li class="line dk"></li>
                    
                    <?php if(!(empty($nav_list) || (($nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator ) && $nav_list->isEmpty()))): if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?>
                        <li>
                            <?php if(($data['pid'] == 0)): ?>
                            <a href="#">
                                <i class="<?php echo $data['icon']; ?>"></i>
                                <span class="nav-label"><?php echo $data['name']; ?></span>
                                <span class="fa arrow"></span>
                            </a>
                            <?php endif; if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;if(($data['id'] == $child['pid'])): ?>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a class="J_menuItem" href="<?php echo url($child['url']); ?>"><?php echo $child['name']; ?></a>
                                    </li>
                                </ul>
                                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; endif; ?>
                  
                   
                    

                    

                </ul>
            </div>
        </nav>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
        <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header"><a class="navbar-minimalize minimalize-styl-2 btn btn-info " href="#"><i class="fa fa-bars"></i> </a>
                       <!--  <form role="search" class="navbar-form-custom" method="post" action="search_results.html">
                            <div class="form-group">
                                <input type="text" placeholder="请输入您需要查找的内容 …" class="form-control" name="top-search" id="top-search">
                            </div>
                        </form> -->
                    </div>
                   
                </nav>
            </div>
            <div class="row J_mainContent" id="content-main">
                <iframe id="J_iframe" width="100%" height="100%" src="<?php echo url('admin/index/welcome'); ?>" frameborder="0" data-id="index_v1.html" seamless></iframe>
            </div>
        </div>
        <!--右侧部分结束-->
    </div>

    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="__admin_style__/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="__admin_style__/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="__admin_style__/js/plugins/layer/layer.min.js"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/hAdmin.js?v=4.1.0"></script>
    <script type="text/javascript" src="__admin_style__/js/index.js"></script>

</body>

</html>
