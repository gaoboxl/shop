<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"D:\www\shop\public/../application/admin\view\menu\edit.html";i:1513586216;}*/ ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> 添加数据 </title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">
   

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        
       
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>菜单列表 <small>编辑数据</small></h5>
                        
                    </div>
                    <div class="ibox-content">
                        <form method="post" class="form-horizontal" action="<?php echo url('menu/update'); ?>">

                            <input type="hidden" name="pid" value="<?php echo $menu['pid']; ?>">
                            <input type="hidden" name="id" value="<?php echo $menu['id']; ?>">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">菜单名称:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="请输入菜单名称" name="name" value="<?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?>"> 
                                    
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">路由地址:</label>
                                <div class="col-sm-4">
                                    <input id="hello" class="laydate-icon form-control layer-date" placeholder="请输入路由地址" name="url" value="<?php echo (isset($menu['url']) && ($menu['url'] !== '')?$menu['url']:''); ?>">
                                    <span class="help-block m-b-none">例(admin/index/index)</span>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Icon:</label>
                                <div class="col-sm-4">
                                    <input id="hello" class="laydate-icon form-control layer-date" placeholder="请输入菜单icon" name="icon" value="<?php echo (isset($menu['icon']) && ($menu['icon'] !== '')?$menu['icon']:''); ?>">
                                    <span class="help-block m-b-none">子菜单不需要icon</span>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">导航显示:</label>

                                <div class="col-sm-4">
                                    <div class="switch">
                                        <div class="onoffswitch">
                                            <input type="checkbox" <?php if(($menu['flag'] == 0)): ?> checked="" <?php endif; ?> class="onoffswitch-checkbox" id="example1" name="flag">
                                            <label class="onoffswitch-label" for="example1">
                                                <span class="onoffswitch-inner" ></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            
                            
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">确定</button>
                                    <button class="btn btn-white" type="button" onClick="javascript :history.back(-1);" >取消</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/content.js?v=1.0.0"></script>

    <script>
        $(document).ready(function () {
           

          

        });
    </script>

    
    

</body>

</html>
