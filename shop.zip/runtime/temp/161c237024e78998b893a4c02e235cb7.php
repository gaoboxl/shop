<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"D:\www\shop\public/../application/admin\view\menu\index.html";i:1513587697;}*/ ?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title> 数据列表 </title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico">
    <link href="__admin_style__/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css?v=4.1.0" rel="stylesheet">
    <!-- 表格样式 -->
    <link href="__admin_style__/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
       
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>菜单列表</h5>
                        <div class="ibox-tools">
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="col-sm-1">
                            <a   class="btn btn-primary " href="<?php echo url('menu/create'); ?>">添加</a>
                        </div>

                        <table class="table table-striped table-bordered table-hover " id="editable">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>菜单名称</th>
                                    <th>时间</th>
                                    <th>导航显示</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!(empty($menus) || (($menus instanceof \think\Collection || $menus instanceof \think\Paginator ) && $menus->isEmpty()))): if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): $i = 0; $__LIST__ = $menus;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu): $mod = ($i % 2 );++$i;?>
                                        <tr class="gradeX">
                                            <td><?php echo $menu['id']; ?></td>
                                            <td><?php echo $menu['name']; ?></td>
                                            <td><?php echo $menu['url']; ?> </td>
                                            <td>
                                                <?php if(($menu['flag'] == 1)): ?>
                                                    <span class="label">否</span>
                                                <?php else: ?>
                                                    <span class="label label-primary">是</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="center">

                                                <?php if(($menu['pid'] == 0)): ?>
                                                <a href="<?php echo url('menu/create',array('pid'=>$menu['id'])); ?>" class=" " title="添加">
                                                    <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                                                </a>&nbsp;
                                                <?php endif; ?>
                                                <a href="<?php echo url('menu/edit',array('id'=>$menu['id'])); ?>" class="" title="编辑">
                                                   <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                                                </a>&nbsp;
                                                <a href="<?php echo url('menu/delete',array('id'=>$menu['id'])); ?>" class="" title="删除">
                                                     <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                                                </a>&nbsp;

                                            </td>
                                        </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; else: ?>

                                <tr class="gradeX">
                                     <td colspan="5" align="center"><h3><i class="fa fa-frown-o"></i> 暂无数据 !</h3> </td>
                                </tr>
                                <?php endif; ?>
                              
                            </tbody>
                           
                        </table>

                        <div class="row">
                            <div class="col-sm-6">
                               <!--  <div class="dataTables_info" id="DataTables_Table_0_info" role="alert" aria-live="polite" aria-relevant="all">显示 1 到 10 项，共 57 项</div> -->
                            </div>
                            <div class="col-sm-6">
                              
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 全局js -->
    <script src="__admin_style__/js/jquery.min.js?v=2.1.4"></script>
    <script src="__admin_style__/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="__admin_style__/js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- 自定义js -->
    <script src="__admin_style__/js/plugins/layer/layer.min.js" ></script>

    <script type="text/javascript">
        
        //删除
        function  del(id)
        {

            layer.confirm('您确定要删除？', {
              btn: ['确定','取消'] //按钮
            }, function(){
             // layer.msg('的确很重要', {icon: 1});

                $.get(url,{id:id},function(rs){

                    if(rs.status == 200){
                        setTimeout(function(){
                            window.location.reload();
                        },1500);
                    }

                    layer.msg('的确很重要', {icon: 1});

                });

            });

        }


        //状态
        function  status(id,status)
        {
            $.get(url,{id:id,status:status},function(rs){

                if(rs.status == 200){
                    layer.msg(rs.msg);
                    window.location.reload();
                }

            });
        }


    </script>

</body>

</html>
