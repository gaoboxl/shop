<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\www\shop\public/../application/admin\view\login\index.html";i:1513157174;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    <title> - 登录</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="__admin_style__/css/bootstrap.min.css" rel="stylesheet">
    <link href="__admin_style__/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="__admin_style__/css/animate.css" rel="stylesheet">
    <link href="__admin_style__/css/style.css" rel="stylesheet">
    <link href="__admin_style__/css/login.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    <script>
        if (window.top !== window.self) {
            window.top.location = window.location;
        }
    </script>
</head>

<body class="signin">
    <div class="signinpanel">
        <div class="row">
            <div class="col-sm-12">
                <form method="post" action="<?php echo url('admin/login/login'); ?>">
                    <?php echo token(); ?>
                    <h4 class="no-margins">登录：</h4>
                    <p class="m-t-md">欢迎使用美丽攻略后台管理</p>
                    <input type="text" class="form-control uname" placeholder="用户名" name="name" />
                    <input type="password" class="form-control pword m-b" placeholder="密码" name="password" />
                    <!-- <a href="">忘记密码了？</a> -->
                    <button class="btn btn-success btn-block" type="submit">登录</button>
                </form>
            </div>
        </div>
        <div class="signup-footer">
            <div class="pull-left">
                &copy; 美丽攻略后台管理系统
            </div>
        </div>
    </div>
</body>

</html>
